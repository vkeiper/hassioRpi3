## 0.1.1
Fix #155 for increments being only .5

## 0.1.0
Add ability to specify external sensor for ambient temperature

## 0.0.2
Fix alignment on Firefox

## 0.0.1
Initial release that supports versioning